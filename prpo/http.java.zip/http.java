import java.util.Random;
import java.io.*;
import java.net.*;


class HTTPServer
{
  public static void main (String[] args)
  {
    System.out.println("Starting server...");
    while (true)
    {
      System.out.println("Waiting for a connection...");

      try (ServerSocket socket = new ServerSocket(8080))
      {
        System.out.println("Listening on port 8080..."); 
                Socket clientSocket = socket.accept();
        System.out.println("Found a connection!");
        InputStream in = clientSocket.getInputStream();
        OutputStream out = clientSocket.getOutputStream();
        
        requestHandler(in, out);

        clientSocket.close();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }
    

  } 
  private static void requestHandler (InputStream in, OutputStream out)
  {
    try
    {
      System.out.println("Handling the request...");
      BufferedReader reader = new BufferedReader(new InputStreamReader(in));

      //handle the header
      String line = reader.readLine();

      String[] lineParts = line.split(" ");

      String method = lineParts[0];
      String URI = lineParts[1];
      String version = lineParts[2];

      PrintWriter writer = new PrintWriter(out, true);
      writer.println("202 bitch");
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    
  }

  
}


